// Kenneth Siu

// 861153851

// 04/21/15

#include <iostream>
#include "lab3.h"

using namespace std;

int main()
{
    cout << "Testing two stacks with maxtop" << endl;
    TwoStackFixed<int> firstStack(10, 4);
    // firstStack.popStack1();
    if (firstStack.isEmptyStack1())
    {
        cout << "First stack is empty!" << endl;
    }
    if (firstStack.isEmptyStack2())
    {
        cout << "Second stack is empty!" << endl;
    }
    firstStack.pushStack1(2);
    firstStack.pushStack1(4);
    firstStack.pushStack1(6);
    firstStack.pushStack1(8);
    firstStack.pushStack2(1);
    firstStack.pushStack2(3);
    firstStack.pushStack2(5);
    firstStack.pushStack2(7);
    
    firstStack.popStack1();
    firstStack.display();
    firstStack.popStack1();
    firstStack.display();
    firstStack.popStack1();
    firstStack.display();
    firstStack.popStack1();
    if (firstStack.isEmptyStack1())
    {
        cout << "First stack is empty!" << endl;
    }
    firstStack.display();
    
    firstStack.popStack2();
    firstStack.display();
    firstStack.popStack2();
    firstStack.display();
    firstStack.popStack2();
    firstStack.display();
    firstStack.popStack2();
    if (firstStack.isEmptyStack2())
    {
        cout << "Second stack is empty!" << endl;
    }
    firstStack.display();
    
    cout << "Done testing the first array" << endl << endl;
    
    cout << "Testing two stacks without maxtop" << endl;
    TwoStackOptimal<int> secondStack(10);
    if (secondStack.isEmptyStack1())
    {
        cout << "First stack is empty!" << endl;
    }
    if (secondStack.isEmptyStack2())
    {
        cout << "Second stack is empty!" << endl;
    }
    
    secondStack.pushFlexStack1(2);
    secondStack.pushFlexStack1(4);
    secondStack.pushFlexStack1(6);
    secondStack.pushFlexStack1(8);
    secondStack.pushFlexStack2(1);
    secondStack.pushFlexStack2(3);
    secondStack.pushFlexStack2(5);
    secondStack.pushFlexStack2(7);
    
    secondStack.popFlexStack1();
    secondStack.display();
    secondStack.popFlexStack1();
    secondStack.display();
    secondStack.popFlexStack1();
    secondStack.display();
    secondStack.popFlexStack1();
    if (secondStack.isEmptyStack1())
    {
        cout << "First stack is empty!" << endl;
    }
    secondStack.display();
    
    secondStack.popFlexStack2();
    secondStack.display();
    secondStack.popFlexStack2();
    secondStack.display();
    secondStack.popFlexStack2();
    secondStack.display();
    secondStack.popFlexStack2();
    if (secondStack.isEmptyStack2())
    {
        cout << "Second stack is empty!" << endl;
    }
    secondStack.display();
    
    cout << "Done testing the second array" << endl << endl;
    
    cout << "Testing the Tower of Hanoi recursive function" << endl;
    stack<int> A;
    A.push(5);
    A.push(3);
    A.push(1);
    stack<int> B;
    stack<int> C;
    showTowerStates(3, A, B, C);
    display(A, B, C);
    cout << endl;
    
    return 0;
}