// Kenneth Siu

// 861153851

// 04/21/15

#ifndef LAB3_H
#define LAB3_H

#include <iostream>
#include <cassert>
#include <stack>

using namespace std;

template<typename T>
class TwoStackFixed
{
 private:
    T* arr;
    int size; // total size
    int maxtop; // location of first element of stack 2
    int s1loc; // location of current location in stack 1
    int s2loc; // location of current location in stack 2
    
 public:
    void display()
    {
        for(int i = 0; i < s1loc+1; i++)
        {
            cout << arr[i] << ' ';
        }
        for(int i = s1loc; i < s2loc; i++)
        {
            cout << "  ";
        }
        for(int i = s2loc; i < size; i++)
        {
            cout << arr[i] << ' ';
        }
        cout << endl;
    }
 
    TwoStackFixed(int size, int maxtop ) // constructor that constructs arr of size and constructs empty stacks with maxtop specifying the partition for stacks.
     : size(size), maxtop(maxtop)
    {
        assert(maxtop*2 <= size);
        arr = new T[size];
        s1loc = -1;
        s2loc = size;
    } // HOW DOES USER SPECIFY THE FIXED AMOUNT OF SPACE FOR EACH STACK?
    ~TwoStackFixed()
    {
        delete [] arr;
    }
    void pushStack1(T value) //to push element into first stack.
    {
        assert(!isFullStack1());
        s1loc++;
        arr[s1loc] = value;
        display();
    }
    void pushStack2(T value) //to push element into second stack.
    {
        assert(!isFullStack2());
        s2loc--;
        arr[s2loc] = value;
        display();
    }
    T popStack1() // to pop element from first stack.
    {
        assert(!isEmptyStack1());
        
        // // TESTING
        // T temp = arr[s1loc];
        
        // T* arr_temp[size];
        // for (int i = 0; i < s1loc - 1; i++) // moving all the elements besides the location of s1loc
        // {
        //     arr_temp[i] = arr[i];
        // }
        // for (int i = s1loc + 1; i < size; i++)
        // {
        //     arr_temp[i] = arr[i];
        // }
        // // deleting the original arr, and setting it equal to the arr_temp
        // delete arr;
        // arr = arr_temp;
        
        // s1loc--;
        
        // return temp;
        
        //ORIGINAL
        T temp = arr[s1loc];
        
        // FIX ME SET DELETED ELEMENT TO BLANK SPACE
        // arr[s1loc] = ' '; // HERE
        
        s1loc--;
        return temp;
    }
    T popStack2() // to pop element from second stack.
    {
        assert(!isEmptyStack2());
        
        // T temp = arr[s1loc];
        
        // T* arr_temp[size];
        // for (int i = size-1; i > s2loc - 1; i--) // moving all the elements besides the location of s1loc
        // {
        //     arr_temp[i] = arr[i];
        // }
        // for (int i = s2loc + 1; i >= 0; i--)
        // {
        //     arr_temp[i] = arr[i];
        // }
        // // deleting the original arr, and setting it equal to the arr_temp
        // delete arr;
        // arr = arr_temp;
        
        // s2loc++;
        
        // return temp;
        
        //ORIGINAL
        T temp = arr[s2loc];
        
        // // FIX ME SET DELETED ELEMENT TO BLANK SPACE
        // arr[s2loc] = ' '; // HERE
        
        s2loc++;
        return temp;
    }
    bool isFullStack1() // helper function to check whether first stack is full.
    {
        if (s1loc == maxtop-1)
        {
            return true;
        }
        return false;
    }
    bool isFullStack2() // helper function to check whether second stack is full.
    {
        if (s2loc == maxtop)
        {
            return true;
        }
        return false;
    }
    bool isEmptyStack1() //helper function to check whether first stack is empty.
    {
        if (s1loc == -1)
        {
            return true;
        }
        return false;
    }
    bool isEmptyStack2() // helper function to check whether second stack is empty.
    {
        if (s2loc == size)
        {
            return true;
        }
        return false;
    }
    // MUST OVERFLOW/UNDERFLOW BE HANDLED IN THIS CASE AS WELL AS THE NEXT? IF SO, WE SHOULD SPECIFY. (mentioned in question)
};

template<typename T>
class TwoStackOptimal
{
 private:
    T* arr;
    int size; // total size
    int s1loc; // location of current location in stack 1
    int s2loc; // location of current location in stack 2
    
 public:
    void display()
    {
        for(int i = 0; i < s1loc+1; i++)
        {
            cout << arr[i] << ' ';
        }
        for(int i = s1loc; i < s2loc; i++)
        {
            cout << "  ";
        }
        for(int i = s2loc; i < size; i++)
        {
            cout << arr[i] << ' ';
        }
        cout << endl;
    }
    
    TwoStackOptimal(int size) // constructor that constructs arr of size and constructs empty stacks.
     : size(size)
    {
        arr = new T[size];
        s1loc = -1;
        s2loc = size;
    }
    ~TwoStackOptimal()
    {
        delete [] arr;
    }
    void pushFlexStack1(T value) // to push element into first stack.
    {
        assert(!isFullStack1());
        // s1loc++;
        // T temp1 = arr[0];
        // T temp2 = 0;
        // for (int i = 1; i < s1loc; i++)
        // {
        //     temp2 = arr[i];
        //     arr[i] = temp1;
        //     temp1 = temp2;
        // }
        // arr[0] = value;
        
        s1loc++;
        arr[s1loc] = value;
        
        display();
    }
    void pushFlexStack2(T value) // to push element into second stack.
    {
        assert(!isFullStack2());
        // s2loc++;
        // T temp1 = arr[size-1];
        // T temp2 = 0;
        // for (int i = size-1; i > size-s2loc; i--)
        // {
        //     temp2 = arr[i];
        //     arr[i] = temp1;
        //     temp1 = temp2;
        // }
        // arr[size-1] = value;
        
        s2loc--;
        arr[s2loc] = value;
        
        display();
    }
    T popFlexStack1() // to pop element into first stack.
    {
        assert(!isEmptyStack1());
        // T returnValue = arr[0];
        
        // T temp1 = arr[s1loc-1];
        // T temp2;
        
        // for (int i = size1-1; i >= 1; i--) // >= ?
        // {
        //     temp1 = arr[i];
        //     arr[i-1] = temp1;
        //     temp1 = temp2;
        // }
        
        // return returnValue;
        
        T temp = arr[s1loc];
        
        // FIX ME SET DELETED ELEMENT TO BLANK SPACE
        // arr[s1loc] = ' '; // HERE
        
        s1loc--;
        return temp;
    }
    
    T popFlexStack2() // to pop element from second stack.
    {
        assert(!isEmptyStack2());
        // T returnValue = arr[size-1];
        
        // T temp1 = arr[s1loc-1];
        // T temp2;
        
        // return returnValue;
        
        T temp = arr[s2loc];
        
        // FIX ME SET DELETED ELEMENT TO BLANK SPACE
        // arr[s2loc] = ' '; // HERE
        
        s2loc++;
        return temp;
    }
    
    bool isFullStack1() // helper function to check whether first stack is full.
    {
        if ((s1loc + 1) ==  s2loc)
        {
            return true;
        }
        return false;
    }
    bool isFullStack2() // helper function to check whether second stack is full.
    {
        if ((s2loc - 1) == s1loc)
        {
            return true;
        }
        return false;
    }
    bool isEmptyStack1() // helper function to check whether first stack is empty.
    {
        if (s1loc == -1)
        {
            return true;
        }
        return false;
    }
    bool isEmptyStack2() // helper function to check whether second stack is empty.
    {
        if (s2loc == size)
        {
            return true;
        }
        return false;
    }
};

template<typename T>
void showTowerStates(int n, stack<T>& A, stack<T>& B, stack<T>& C, const char x, const char y, const char z)
{
    // 1) Move top disks from A to B
    // 2) Move 1 disk from A to C
    // 3) Move top disks from B to C
    if (n == 1)
    {
        cout << "Moved " << A.top() << " from peg " << x << " to " << z << endl;
        C.push(A.top());
        A.pop();
    }
    else
    {
        showTowerStates(n-1, A, C, B, 'A', 'C', 'B');
        showTowerStates(1, A, B, C, 'A', 'B', 'C');
        showTowerStates(n-1, B, A, C, 'B', 'A', 'C');
    }
}

template<typename T>
void showTowerStates(int n, stack<T>& A, stack<T>& B, stack<T>& C) // n refers to number of elements in source stack A
{
    assert(n > 0);
    showTowerStates(n, A, B, C, 'A', 'B', 'C');
}

template<typename T>
void display(stack<T> A, stack<T> B, stack<T> C)
{
    cout << "Stack A: ";
    while (!A.empty())
    {
        cout << A.top() << ' ';
        A.pop();
    }
    cout << endl;
    cout << "Stack B: ";
    while (!B.empty())
    {
        cout << B.top() << ' ';
        B.pop();
    }
    cout << endl;
    cout << "Stack C: ";
    while (!C.empty())
    {
        cout << C.top() << ' ';
        C.pop();
    }
    cout << endl;
}

#endif