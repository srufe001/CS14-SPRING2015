// Kenneth Siu

// 861153851

// 04/28/15

#include <iostream>
#include "lab4.h"

using namespace std;

int main(int argc, char *argv[])
{
    int k = *argv[1] - '0' - argc + argc;

    cout << "Pre Order" << endl;
    listPreOrder(k);
    cout << endl;
    
    cout << "Post Order" << endl;
    listPostOrder(k);
    cout << endl;
    
    cout << "Sorted Order" << endl;
    sortedOrder(k);
    cout << endl;
    
    // print(k);
    
    return 0;
}