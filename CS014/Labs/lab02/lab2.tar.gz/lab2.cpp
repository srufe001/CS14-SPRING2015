// Kenneth Siu

// 861153851

// 04/15/15

#include <iostream>
#include <iterator>
#include <forward_list>
#include "lab2.h"

using namespace std;

//helper function - checks if number is prime or not
bool isPrime(int i)
{
    if (i == 0 || i == 1)
    {
        return false;
    }
    for(int j = 2; j < i; j++)
    {
        if(i%j == 0)
        {
            return false;
        }
    }
    return true;
}

int primeCount(forward_list <int> lst) //count the number of prime numbers in a numerical singly linked list
{
    if (lst.empty())
    {
        return 0;
    }
    
    if(isPrime(lst.front()))
    {
        lst.pop_front();
        return 1+primeCount(lst);
    }
    else
    {
        lst.pop_front();
        return primeCount(lst);
    }
}

template<typename T>
// typedef int T;

void display(forward_list <T> lst)
{
    if (lst.empty())
    {
        return;
    }
    while (!lst.empty())
    {
        cout << lst.front() << ' ';
        lst.pop_front();
    }
}

template<typename T>
// typedef int T;

void listCopy (forward_list<T> L, forward_list <T> & P ) //copy a singly linked list L into a second singly linked list P in reverse order by only traversing L once
{
    forward_list<T> Ptemp;
    
    while(!P.empty())
    {
        Ptemp.push_front(P.front());
        P.pop_front();
    }
    
    while(!L.empty())
    {
        P.push_front(L.front());
        L.pop_front();
    }
    
    while(!Ptemp.empty())
    {
        P.push_front(Ptemp.front());
        Ptemp.pop_front();
    }
}

template<typename T>
// typedef int T;

void printLots (forward_list<T> L, forward_list <int> P) //print the elements in L that are in positions specified by P
{
    if (P.front() == 0)
    {
        cout << L.front() << ' ';
        L.pop_front();
        P.pop_front();

        int y = 0;
        while (!P.empty())
        {
            P.front() = P.front() - 1;
            int x = P.front() - y;
            for (int i = 0; i < x; i++)
            {
                L.pop_front();
                if (L.empty())
                {
                    cout << "Out of bounds: reached end of list L" << endl;
                    return;
                }
            }
            cout << L.front() << ' ';
            y = P.front();
            P.pop_front();
        }
    }
    else
    {
        int y = 0;
        while (!P.empty())
        {
            int x = P.front() - y;
            for (int i = 0; i < x; i++)
            {
                L.pop_front();
                if (L.empty())
                {
                    cout << "Out of bounds: reached end of list L" << endl;
                    return;
                }
            }
            cout << L.front() << ' ';
            y = P.front();
            P.pop_front();
        }
    }
}

int main()
{
    // Checking for Prime Count
    forward_list <int> temp;
    temp.push_front(1);
    temp.push_front(3);
    temp.push_front(5);
    temp.push_front(7);
    temp.push_front(2);
    temp.push_front(4);
    temp.push_front(6);
    temp.push_front(8);
    // 8 6 4 2 7 5 3 1
    
    cout << "Counting prime numbers" << endl;
    cout << "Expecting: 4" << endl;
    cout << "Received: ";
    cout << primeCount(temp) << endl;
    
    forward_list <int> charTemp;
    charTemp.push_front(2);
    charTemp.push_front(1);
    charTemp.push_front(0);
    // 0 1 2
    
    cout << "Copying list charTemp in reverse order into list temp" << endl;
    cout << "Expecting: 0 1 2 1 3 5 7 2 4 6 8" << endl;
    cout << "Received: ";
    listCopy(temp, charTemp);
    // cout << charTemp.front();
    display(charTemp); cout << endl;
    
    forward_list <int> lotsList;
    lotsList.push_front(4);
    lotsList.push_front(2);
    lotsList.push_front(0);
    cout << "Print lots function"  << endl;
    cout << "Printing locations 0 2 4 of list temp" << endl; //8 6 4 2 7 5 3 1
    cout << "Expecting: 8 4 7" << endl;
    cout << "Received: ";
    printLots(temp, lotsList); cout << endl;
    
    forward_list <int> lotsList2;
    lotsList2.push_front(5);
    lotsList2.push_front(3);
    lotsList2.push_front(1);
    cout << "Printing locations 1 3 5 of list temp" << endl; //8 6 4 2 7 5 3 1
    cout << "Expecting: 6 2 5" << endl;
    cout << "Received: ";
    printLots(temp, lotsList2); cout << endl;
    
    forward_list <int> lotsList3;
    lotsList3.push_front(8);
    lotsList3.push_front(7);
    cout << "Printing locations 1 3 5 of list temp" << endl; //8 6 4 2 7 5 3 1
    cout << "Expecting: 1 Out of bounds: reached end of list L" << endl;
    cout << "Received: ";
    printLots(temp, lotsList3); cout << endl;
    
    List<int> lst;
    for (int i = 0; i < 7; i++)
    {
        lst.push_back(i);
    }
    // 0 1 2 3 4 5 6 
    lst.elementSwap(0);
    // 1 0 2 3 4 5 6 
    lst.elementSwap(5);
    // 1 0 2 3 4 6 5 
    lst.print();
    cout << endl;
    
    return 0;
}