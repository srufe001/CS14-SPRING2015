// Kenneth Siu

// 861153851

// 04/15/15

#ifndef LAB2_H
#define LAB2_H

#include <iostream>
#include <cassert>

using namespace std;

template<typename T>
// typedef int T;

struct Node
{
    T data;
    Node *next;
    Node(T data) : data(data), next(0) {}
};

template<typename T>
// typedef int T;

class List
{
 private:
    Node<T>* head;
    Node<T>* tail;
    
 public:
    List() : head(0), tail(0) {}
    
    int size() const
    {
        int i = 0;
        for (Node<T>* temp = head; temp != 0; temp = temp->next) //check temp != head works?
        {
            i++;
        }
        return i;
    }
    
    void push_back(T value)
    {
        Node<T>* tmp = new Node<T>(value);
        if (tail != 0)
        {
            tail->next = tmp;
        }
        tail = tmp;
        if (head == 0)
        {
            head = tail;
        }
    }
    
    void print() const
    {
        for (Node<T>* temp = head; temp != 0; temp = temp->next)
        {
            cout << temp->data << ' ';
        }
    }
 
    List<T> elementSwap( int pos ) //swap two adjacent elements pos and pos+1 of a singly linked list by adjusting only the links (and not the data)
    {
        assert(pos < size() - 1 && pos >= 0);
        
        Node<T>* curr = head;
        Node<T>* after = curr->next;
        
        if(pos == 0)
        {
            Node<T>* temp = after;
            if (tail == temp)
            {
                tail = head;
            }
            head->next = temp->next;
            temp->next = head;
            head = temp;
        }
        
        else if (pos > 0)
        {
            for (int i = 0; i < pos - 1; i++)
            {
                curr = curr->next;
                after = after->next;
            }
            
            Node<T>* subsequent = after->next;
            after->next = subsequent->next;
            curr->next = subsequent;
            subsequent->next = after;
        }
        
        return *this;
    }
};

#endif