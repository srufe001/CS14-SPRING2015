// Kenneth Siu

// 861153851

// 04/28/15

#ifndef LAB4_H
#define LAB4_H

#include <iostream>
#include <stack>
#include <queue>
#include <utility>

using namespace std;

void listPreOrderHelper(int m, int n, int k)
{
    if((m+n) > k)
    {
        return;
    }
   
    cout << m << ' ' << n << endl;
   
    listPreOrderHelper(2 * m - n, m, k);
    listPreOrderHelper(2 * m + n, m, k);
    listPreOrderHelper(m + 2 * n, n, k);
}
 
void listPreOrder(int k)
{
    listPreOrderHelper(2, 1, k);
    listPreOrderHelper(3, 1, k);
}

void listPostOrderHelper(int m, int n, int k)
{
    if ((m+n) >= k)
    {
        return;
    }
   
    listPostOrderHelper(2 * m - n, m, k);
    listPostOrderHelper(2 * m + n, m, k);
    listPostOrderHelper(m + 2 * n, n, k);
    
    cout << m << ' ' << n << endl;
}

void listPostOrder(int k)
{
    listPostOrderHelper(2, 1, k);
    listPostOrderHelper(3, 1, k);
}

void sortedOrderHelper(int m, int n, int k, priority_queue<pair<int, pair<int, int> > > &q)
{
    if((m+n) >= k)
    {
        return;
    }
   
    q.push(pair<int, pair<int, int> > (m + n, pair<int,int> (m, n)));
   
    sortedOrderHelper(2 * m - n, m, k, q);
    sortedOrderHelper(2 * m + n, m, k, q);
    sortedOrderHelper(m + 2 * n, n, k, q);
}

void sortedOrder(int k)
{
    priority_queue<pair<int, pair<int,int> > > q;
   
    sortedOrderHelper(2, 1, k, q);
    sortedOrderHelper(3, 1, k, q);
   
    stack<pair<int,int> > s;
   
    while(!q.empty())
    {
        s.push(q.top().second);
        q.pop();
    }
   
    while(!s.empty())
    {
        cout << s.top().first << ' ' << s.top().second << endl;
        s.pop();
    }
}

#endif